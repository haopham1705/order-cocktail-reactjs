import React, { useEffect, useState } from 'react'
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router'
// import {createBrowserHistory} from 'history'
import { GlobalActions } from '../../redux/slices/globalSlice'
import './LoginPage.scss'

export default function LoginPage(props) {
    const dispatch = useDispatch()
    const history = useHistory()

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [msg, setMsg] = useState('')

    const handleLogin = () => {
        // e.preventDefault();
        console.log(username, password)
        if (username !== '' && password !== '') {
            if (username === 'admin' && password === 'admin') {
                localStorage.setItem('username', username)
                localStorage.setItem('password', password)
                history.push('/')
                console.log('login success')
                setUsername('')
                setPassword('')
                setMsg('')
            } else {
                setMsg("Please enter correct username & password")
            }
        }
    }

    useEffect(() => {
        dispatch(GlobalActions.showLoading())
        setTimeout(() => {
            dispatch(GlobalActions.showLoading())
        }, 1200)
    }, [])

    return (
        <div className="login-form fadeInDown">
            <div className="formContent">
                <img className="formContent__icon" src="http://haopham.co/img/logo_livef.png" id="icon" alt="User Icon" />

                <h1 className="login-form__title"> Sign In </h1>
                <form>
                    <input type="text" onChange={(e) => setUsername(e.target.value)} id="login" className="fadeIn second" name="login" placeholder="username" required />
                    <input type="password" onChange={(e) => setPassword(e.target.value)} id="password" className="fadeIn third" name="login" placeholder="password" required />

                    <button className="fadeIn fourth btn" onClick={handleLogin}>Log In</button>
                </form>
                <span className='errorMsg'>{msg}</span>
            </div>
        </div>
    )
}
